pi@raspberrypi:~/git/pifm/PiFMPlay/pifmplay $ ./pifmplay http://media-ice.musicradio.com/LBCLondonMP3Low 103.7
DEBUG: its an URL!
DEBUG: playurl
PiFMPlaying: URL http://media-ice.musicradio.com/LBCLondonMP3Low, frequency 103.7
DEBUG: playmp3ffmpeg
ffmpeg version 3.1.1 Copyright (c) 2000-2016 the FFmpeg developers
  built with gcc 4.9.2 (Raspbian 4.9.2-10)
  configuration: --prefix=/usr --enable-gpl --enable-libx264 --enable-nonfree --enable-shared --disable-static
  libavutil      55. 28.100 / 55. 28.100
  libavcodec     57. 48.101 / 57. 48.101
  libavformat    57. 41.100 / 57. 41.100
  libavdevice    57.  0.101 / 57.  0.101
  libavfilter     6. 47.100 /  6. 47.100
  libswscale      4.  1.100 /  4.  1.100
  libswresample   2.  1.100 /  2.  1.100
  libpostproc    54.  0.100 / 54.  0.100
Input #0, mp3, from 'http://media-ice.musicradio.com/LBCLondonMP3Low':
  Metadata:
    icy-br          : 48
    icy-description : LBC London
    icy-genre       : Talk
    icy-name        : LBC London
    icy-private     : 0
    icy-pub         : 0
    StreamTitle     : 
    StreamUrl       : 
    UTC             : 20170113T224959.123
  Duration: N/A, start: 0.000000, bitrate: 48 kb/s
    Stream #0:0: Audio: mp3, 44100 Hz, mono, s16p, 48 kb/s
[s16le @ 0xca6b00] Using AVStream.codec to pass codec parameters to muxers is deprecated, use AVStream.codecpar instead.
Output #0, s16le, to 'pipe:':
  Metadata:
    icy-br          : 48
    icy-description : LBC London
    icy-genre       : Talk
    icy-name        : LBC London
    icy-private     : 0
    icy-pub         : 0
    StreamTitle     : 
    StreamUrl       : 
    UTC             : 20170113T224959.123
    encoder         : Lavf57.41.100
    Stream #0:0: Audio: pcm_s16le, 22050 Hz, mono, s16, 352 kb/s
    Metadata:
      encoder         : Lavc57.48.101 pcm_s16le
Stream mapping:
  Stream #0:0 -> #0:0 (mp3 (native) -> pcm_s16le (native))
Press [q] to stop, [?] for help


